#Labo05

1. Lancer tasks.html dans votre navigateur préféré.
2. Apprécier l'application.

Note: 
Dans certains cas, je n'arrive pas à utiliser jquery avec la fonction .val(). 
getElementByID.value fonctionne bien mais pas .val() ne fonctionne pas.
Ceci arrive à quelques endroits dans le code mais j'ai utilisé jquery partout ailleurs.